/*
ScrollReveal().reveal('.scroll-1', {duration: 1000});
*/

/*
let meuArray = [1,2,3,4,5]
meuArray.splice(2,0,"x","y","z");
console.log(meuArray)

const observer = new IntersectionObserver(entries)

*/

/*
let frutas =[ 
{nome: "banana",
 cor: "amarela",
 preco: 1.09  
},
{
    nome: "maca",
    cor:"vermelha",
    preco: 1.69
}

]

for (let fruta in frutas){
    console.log(frutas)

}

console.log("########")

for(let fruit of frutas){
    
    fruit.nome="melão"
    console.log(fruit)
}


*/




arrayDeObjetos=[ 
    
    {
        id: 1,
        nome: "tomate",
        preco: 1.99
},
{
    id: 2,
        nome: "banana",
        preco: 1.09
}



]

console.log(arrayDeObjetos.length)




// FUNÇÃO NORMAL

function nomeDaFunção() {

}


// ARROW FUNCTION

() => {

}     

/* se tiver só uma operação não precisa de chaves, 
        e o return já é feito IMPLICITAMENTE!